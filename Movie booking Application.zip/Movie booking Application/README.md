# Online-Movie-Ticket-Booking---using---Jsp
Online Movie Ticket Booking project with full database Connectivity using Jsp

Admin 
Admin can Add the Employee Details.Admin Can also see all the Transcations like customer,employee,movie schedule,ticketCost and more.

Employee
Employee Registers through Employee Registration Portal.Admin Has to add the Employee details Initially,then only the Employee will have 
the chance to Register and login into his Protal.In Employee Portal,he/she can Add the movie Schedule,Update their Info and can see Customer
Transcation.

Customer
Customer can login in his/her portal using Username And Password.Once Logins,he can book Movie Ticket with Specific movie Name and can also 
check their Transcation History,update his Personal Information and Download the E-ticket.
